#include <htc.h>

#pragma config INTOSCSEL = HIGH, SOSCSEL = DIG, XINST = OFF, RETEN = OFF, FOSC = EC3, PLLCFG = ON, BOREN =OFF, WDTEN = OFF, RTCOSC = INTOSCREF, MCLRE = ON

#define PROG_START 0x1000
#define UI_SWITCH 		(!PORTBbits.RB2)
#define LCD_DB  LATD
#define LCD_BL  LATBbits.LATB1
#define LCD_RS 	LATEbits.LATE5
#define LCD_RW	LATEbits.LATE6
#define LCD_E	LATEbits.LATE7
#define LCD_TOGGLE() LCD_E=1;NOP();NOP();NOP();NOP();NOP();NOP();NOP();LCD_E=0;NOP();NOP();NOP();NOP();

union LONG {
    unsigned char ub[4];
    signed char b[4];
    unsigned int ui[2];
    signed int i[2];
    unsigned long ul;
    signed long l;
};


void Set_Pins(void);
void Setup_UART(void);
void putc(unsigned char dat);
void Delay_ms(int ms);
unsigned char getc(void);
signed char gethex(void);
void LCD_ClearDisplay(void);
void LCD_PowerUp(void);
void LCD_SetPosition(char Row, char Col);
void LCD_FunctionSet(char EightBit, char DualLine, char FiveByTenDots);
void LCD_CursorShift(char ShiftDisplay, char ShiftRight);
void LCD_DisplayOnOff(char DisplayOn, char CursorOn, char BlinkOn);
void LCD_EntryModeSet(char Increment, char ShiftOn);
void LCD_ReturnHome(void);
//void LCD_PrintString(const unsigned char *dat);
void LCD_PrintChar(char dat);


#asm
psect intcode	// redirect interrupts to new routine addresses
	goto	PROG_START+8
psect intcodelo // redirect low priority interrupts to new routine addresses
    goto    PROG_START+0x18
#endasm

void main(void)
{
	unsigned char cc=0;
	unsigned char ab=0;
	unsigned char Buffer[128];
	unsigned char inp;
	unsigned char idx;
	signed char temp;
	unsigned char tbuf;
	unsigned char CheckSum;
	union LONG BlockAddress;
	
	//Interal Oscillator @ 16Mhz	
	OSCCON=0b01110000;
	
	//Enable the 4X PLL	
	PLLEN=1;
		
	PIE1=0;	// as per the errata document for these parts
	// Some devices' errata require these registers to be cleared
	INTCON3=0;	// Also serves to disable interrupts
	PIE2=0;
	INTCON=0;
	
	Delay_ms(500);
	//Check to see if we should run the boot loader...
	//If the switch is not pressed at start up then run the normal program
    if (!UI_SWITCH)
    {   
	   asm("goto " ___mkstr(PROG_START)); 
	} 
	
	Set_Pins();
	Setup_UART();
	
	LCD_PowerUp();
	LCD_PrintChar('R');
	LCD_PrintChar('E');
	LCD_PrintChar('A');
	LCD_PrintChar('D');
	LCD_PrintChar('Y');
	LCD_PrintChar(' ');
	LCD_PrintChar('F');
	LCD_PrintChar('O');
	LCD_PrintChar('R');
	LCD_PrintChar(' ');
	LCD_PrintChar('F');
	LCD_PrintChar('I');
	LCD_PrintChar('R');
	LCD_PrintChar('M');
	LCD_PrintChar('W');
	LCD_PrintChar('A');
	LCD_PrintChar('R');
	LCD_PrintChar('E');		
	INTCONbits.GIE=0;	
	while(1)
	{
WaitForBlock:
		//Wait for a start of block character
		while(1)
		{			
			inp=getc();			
			switch (inp)
			{				
				case '!':					
					goto RecieveBlock;	//Start of block
				case '#':					
					RESET();	//End of program
					break;
				case '?':					
					putc('/');	//Respond to a ping request
					break;
				case 'X':
					LCD_ClearDisplay();
					LCD_PrintChar('F');
					LCD_PrintChar('I');
					LCD_PrintChar('N');
					LCD_PrintChar('I');
					LCD_PrintChar('S');
					LCD_PrintChar('H');
					LCD_PrintChar('E');
					LCD_PrintChar('D');						
					putc('X');
					break;
				case 'x':
					asm("goto " ___mkstr(PROG_START)); 
					break;
					
				default:		
					putc('%');	//Inform the host of an error and to try again
					break;
			}	
		}	
		
RecieveBlock:
		INTCONbits.GIE=0;		
		CheckSum=0;	
			
		BlockAddress.ul=0;
		//Get the block address [LOWER(7-4), LOWER(3-0), UPPER(7-4), UPPER(3-0)]
		temp=gethex();
		if (temp==-1) goto rxerror;
		BlockAddress.ub[0]=temp<<4;	//LSB upper 4 bits		
		temp=gethex();
		if (temp==-1) goto rxerror;
		BlockAddress.ub[0]+=temp;	//LSB lower 4 bits

		temp=gethex();
		if (temp==-1) goto rxerror;
		BlockAddress.ub[1]=temp<<4;	//LSB upper 4 bits		
		temp=gethex();
		if (temp==-1) goto rxerror;
		BlockAddress.ub[1]+=temp;	//LSB lower 4 bits
		
		BlockAddress.ul<<=7;  //Shift up past the 7-bits of inter-block space
		
		//Get the 128bytes of Data
		for (idx=0;idx<128;idx++)
		{
			temp=gethex();
			if (temp==-1) goto rxerror;
			tbuf=temp;
			tbuf<<=4;
			temp=gethex();
			if (temp==-1) goto rxerror;
			tbuf+=temp;
			Buffer[idx]=tbuf;
			CheckSum+=tbuf;
		}
			
		
		/*//Get the checksum 
		temp=gethex();
		if (temp==-1) goto rxerror;
		tbuf=temp;
		tbuf<<=4;
		temp=gethex();
		if (temp==-1) goto rxerror;
		tbuf+=temp;
		CheckSum+=tbuf;
		
		//Check to see if the Checksum result is not Zero
		//A Non-Zero checksum indicates an error
		if(CheckSum) goto rxerror;		*/
		
		//Erase the Flash Block		
		//Point to the block to erase
		TBLPTRL=BlockAddress.ub[0];	//Upper two bits = Block Address Bits (1-0)
		TBLPTRH=BlockAddress.ub[1];	//Maps to Block Address Bits (10-2)
		TBLPTRU=BlockAddress.ub[2];	//Maps to Block Address Bits (16-11)
		
		//Setup for the erase operation
		EECON1bits.EEPGD=1;
		EECON1bits.CFGS=0;
		EECON1bits.WREN=1;
		EECON1bits.FREE=1;		
		EECON2=0x55;
		EECON2=0xAA;
		EECON1bits.WR=1;	
		while (	EECON1bits.WR) NOP();
		EECON1bits.WREN=0;
		
		//Program FLASH 		
		//Point to the block to program
		TBLPTRL=BlockAddress.ub[0];	//Upper two bits = Block Address Bits (1-0)
		TBLPTRH=BlockAddress.ub[1];	//Maps to Block Address Bits (10-2)
		TBLPTRU=BlockAddress.ub[2];	//Maps to Block Address Bits (16-11)
		
		//Write the 128 bytes of data into the FLASH Registers
		//The first write doesn't increment the table pointer
		TABLAT=Buffer[0];
		asm("TBLWT*");		
		for (idx=1;idx<128;idx++)
		{
			TABLAT=Buffer[idx];
			asm("TBLWT+*");	//Increment the Table Pointer then write
		}
		
		//Actually write the FLASH
		EECON1bits.EEPGD=1;
		EECON1bits.CFGS=0;
		EECON1bits.WREN=1;		
		EECON2=0x55;
		EECON2=0xAA;
		EECON1bits.WR=1;		
		while (	EECON1bits.WR) NOP();
		EECON1bits.WREN=0;
		
		if (EECON1bits.WRERR) goto rxerror;
		
		//Tell the host that the last block was good and 
		//we are ready for the next block...
		if (cc==0) LCD_SetPosition(1,0);
		if (ab==0) LCD_PrintChar('*'); else LCD_PrintChar('-');
		cc++;
		if (cc>19)
		{
			cc=0;
			if (ab) ab=0; else ab=1;
		}	
		
		putc('*');
		
		goto WaitForBlock;
rxerror:
		putc('%');
		goto WaitForBlock;		
	}	
	

}

void putc(unsigned char dat)
{
	while (TXSTA1bits.TRMT==0) NOP();	
	TXREG=dat;	
}	

unsigned char getc(void)
{
	unsigned char temp=0;
	while(!RC1IF)
	{
		if ((RCSTA1bits.OERR) | (RCSTA1bits.FERR))
		{
			RCSTA1bits.CREN=0;
			NOP();
			RCSTA1bits.CREN=1;
			temp=RCREG;
			temp=RCREG;
			return(0);	
		}	
		/*
		temp++;		
		LCD_SetPosition(1,0);
		if (temp<128) LCD_PrintChar(' '); else LCD_PrintChar('*');*/
	}	 
	temp=RCREG;
	return (temp);
}	

signed char gethex(void)
{
	unsigned char temp;
	temp=getc();
	if (temp==0) return(-1);
	if (temp<'0') return(-1);
	if (temp>'@')
	{
		temp-='A';
		temp+=10;
		if (temp>15) return(-1);
		return(temp);
	}	
	temp-='0';
	if (temp>9) return(-1);
	return(temp);
}		
		
	
void Set_Pins()
{
    //PORTA:
    //RA0 - MOTOR ENCODER A (INPUT)
    //RA1 - MOTOR ENCODER A (INPUT)
    //RA2 - N/C (Output)
    //RA3 - N/C (Output)
    //RA4 - N/C (Output)
    //RA5 - N/C (Output)
    //RA6 - OSC. OUT (Output)
    //RA7 - OSCILLATOR (Input)
    LATA = 0b00000000;
    TRISA = 0b10000011;


    //PORTB
    //RB0 - Motor Reverse (Output)
    //RB1 - LCD Back Light (Output)
    //RB2 - UI Switch (Input)
    //RB3 - UI Encoder A (Input)
    //RB4 - UI Encoder B (Input)
    //RB5 - N/C (Output)
    //RB6 - Program Clock (PGC) (Output)
    //RB7 - Pogram Data (PGD) (Output)
    LATB = 0b00000000;
    TRISB = 0b00011100;
    RBPU = 0; //Enable Pull Ups


    //PORTC
    //RC0 - Motor Forward (Output)
    //RC1 - N/C (Output)
    //RC2 - Motor PWM (Output)
    //RC3 - N/C (Output)
    //RC4 - N/C (Output)
    //RC5 - N/C (Output)
    //RC6 - MCU Serial TX (Output)
    //RC7 - MCU Serial RX (Input)
    LATC = 0b00000000;
    TRISC = 0b10000000;

    //PORTD
    //RB0-RB7 - LCD Data Bus (Outputs)
    LATD = 0b00000000;
    TRISD = 0b00000000;

    //PORTE
    //RE0 - N/C (Output)
    //RE1 - N/C (Output)
    //RE2 - N/C (Output)
    //RE3 - N/C (Output)
    //RE4 - N/C (Output)
    //RE5 - LCD RS (Output)
    //RE6 - LCD R/W (Output)
    //RE7 - LCD E Strobe (Output)
    LATE = 0b00000000;
    TRISE = 0b00000000;

    //PORTF
    //RF0 - NO PIN (Output)
    //RF1 - N/C (Output)
    //RF2 - Battery Voltage (Input)
    //RF3 - N/C (Output)
    //RF4 - N/C (Output)
    //RF5 - N/C (Output)
    //RF6 - N/C (Output)
    //RF7 - N/C (Output)
    LATF = 0b00000000;
    TRISF = 0b00000100;

    //PORTG
    //RG0 - N/C (Output)
    //RG1 - N/C (Output)
    //RG2 - N/C (Output)
    //RG3 - N/C (Output)
    //RG4 - N/C (Output)
    //RG5 - No PIN (Output)
    //RG6 - No PIN (Output)
    //RG7 - No PIN (Output)
    LATG = 0b00000000;
    TRISG = 0b00000000;

    //Setup ADC Pins
    //AN7 - Battery Input
    //All Others --- DISABLE ---
    ANCON0 = 0b10000000;
    ANCON1 = 0;
    ANCON2 = 0;

    //Setup ADC
    //AN7 Selected & ADC Off
    ADCON0 = 0b00011100;
    //Right Justified, ADC Clock= Fosc/64
    ADCON2 = 0b10111110;
    //Turn off the ADC
    ADON = 0;
}

void Setup_UART(void)
{
    //Setup Pins
    TRISCbits.TRISC7 = 1;
    TRISCbits.TRISC = 0;

    //Setup USART
    TXSTA1bits.BRGH = 1; //High Bit Rate Mode
    BAUDCON1bits.BRG16 = 1; //16-bit Baud Rate Generator Only
    BAUDCON1bits.RXDTP = 0; //RX signal is NOT inverted (Active-high)
    BAUDCON1bits.TXCKP = 0; //TX Signal is NOT inverted (Active-high)
    BAUDCON1bits.WUE = 0; //Wake Up is NOT enabled
    BAUDCON1bits.ABDEN = 0; //Auto baud rate is NOT enabled
    

    //Fosc=64Mhz
    //Baud=115200bps
    //BRGH=1, 16-Bit
    //Baud=Fosc/[4/(BRG+1)]
    //BRG=137 (115,942bps @ 0.64% Error)
    SPBRGH1 = 0;
    SPBRG1 = 137;

    TXSTA1bits.SYNC = 0; //Async Mode
    RCSTA1bits.SPEN = 1; //Serial Port Enabled

    TX1IE = 0; //Disable Interrupts
    TXSTA1bits.TX9 = 0; //8-bit Mode
    TXSTA1bits.TXEN = 1; //TX Enabled

    RC1IE = 0; //Disable Interrupts
    RCSTA1bits.RC9 = 0; //8-bit Mode
    RCSTA1bits.CREN = 1; //Async Mode Enable Reciever
}

void Delay_ms(int ms)
{
	int idx;
	int temp;
	
	for (idx=0;idx<ms;idx++)
	{
		//Delay for 1 ms
		for (temp=0;temp<1454;temp++) NOP();
	}		
	return;	
}	
	
void LCD_PrintChar(char dat)
{
	LCD_E=0;
	LCD_RS=1;
	LCD_RW=0;
	LCD_DB=dat;
	LCD_TOGGLE()  
	Delay_ms(1);      
}	

/*void LCD_PrintString(const unsigned char *dat)
{
	unsigned char a;
	while (*dat)
	{
		a=*dat;
		LCD_PrintChar(a);
		dat++;
	}	
}*/	

void LCD_SetPosition(char Row, char Col)
{
	unsigned char dat = Col;
	if (Row==1) dat+=0x40;
	dat |=0b10000000;
	
	LCD_E=0;
	LCD_RS=0;
	LCD_RW=0;
	LCD_DB=dat;
	LCD_TOGGLE()
  	Delay_ms(1);
}

void LCD_PowerUp()
{  	
	//Pause 30ms
     Delay_ms(60);
	
	//8-Bit, 2 Line, 5x7 Dots
	LCD_FunctionSet(1,1,1);
		
	//Display ON, Cursor OFF, Blink OFF
	LCD_DisplayOnOff(1,0,0);
		
	//Clear the Display
	LCD_ClearDisplay();

    Delay_ms(30);

	//8-Bit, 2 Line, 5x7 Dots
	LCD_FunctionSet(1,1,1);

	//Display ON, Cursor OFF, Blink OFF
	LCD_DisplayOnOff(1,0,0);

	//Clear the Display
	LCD_ClearDisplay();
        
}
	

void LCD_ClearDisplay(void)
{
	LCD_RS=0;
	LCD_RW=0;
	LCD_DB=0b00000001;
	LCD_TOGGLE()
	Delay_ms(2);
}
	
void LCD_ReturnHome(void)
{	
	LCD_RS=0;
	LCD_RW=0;
	LCD_DB=0b00000010;
    LCD_TOGGLE()
    Delay_ms(2);
}		

void LCD_EntryModeSet(char Increment, char ShiftOn)
{
	unsigned char dat=0b00000100;
	if (Increment) dat|=0b00000010;
	if (ShiftOn) dat|=0b00000001;
	
	LCD_E=0;
	LCD_RS=0;
	LCD_RW=0;
	LCD_DB=dat;
	LCD_TOGGLE()
	Delay_ms(2);
}

void LCD_DisplayOnOff(char DisplayOn, char CursorOn, char BlinkOn)
{
	unsigned char  dat =0b00001000;
	if (DisplayOn) dat|=0b00000100;
	if (CursorOn)  dat|=0b00000010;
	if (BlinkOn)   dat|=0b00000001;
	
	LCD_E=0;
	LCD_RS=0;
	LCD_RW=0;
	LCD_DB=dat;
	LCD_TOGGLE()
	Delay_ms(2);
	
}

void LCD_CursorShift(char ShiftDisplay, char ShiftRight)
{
	unsigned char  		dat =0b00010000;
	if (ShiftDisplay) 	dat|=0b00001000;
	if (ShiftRight) 	dat|=0b00000100;
	
	LCD_E=0;
	LCD_RS=0;
	LCD_RW=0;
	LCD_DB=dat;
	LCD_TOGGLE()
    Delay_ms(2);
}

void LCD_FunctionSet(char EightBit, char DualLine, char FiveByTenDots)
{
	unsigned char  		dat =0b00100000;
	if (EightBit) 		dat|=0b00010000;
	if (DualLine) 		dat|=0b00001000;
	if (FiveByTenDots) 	dat|=0b00000100;
	
	LCD_E=0;
	LCD_RS=0;
	LCD_RW=0;
	LCD_DB=dat;
	LCD_TOGGLE()
	Delay_ms(2);
}
